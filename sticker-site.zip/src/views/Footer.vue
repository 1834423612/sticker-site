<template>
    <footer class="footer">
      <div class="container">
        <span class="text">这里是页脚内容</span>
      </div>
    </footer>
  </template>
  
  <style scoped>
  .footer {
    background-color: #f5f5f5;
    padding: 20px;
    text-align: center;
  }
  
  .container {
    max-width: 1200px;
    margin: 0 auto;
  }
  
  .text {
    color: #333;
  }
  </style>
  